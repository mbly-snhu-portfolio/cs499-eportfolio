# Artifact Analysis: Grazioso Salvare Animal Shelter Dashboard

## Overview

**Artifact Name**: Grazioso Salvare Animal Shelter Dashboard  
**Origin**: CS-340 Advanced Programming Concepts  
**Creation Date**: Module 4-6 (Final submission: August 2024)  
**Technology Stack**: Python, Dash, PyMongo, MongoDB, Jupyter Notebooks

## Current Architecture

### Architecture Pattern
The current implementation follows an **MVC (Model-View-Controller) pattern** within a Jupyter notebook:

- **Model**: MongoDB database accessed via `AnimalShelter` CRUD class
- **View**: Dash components (table, chart, map, controls)
- **Controller**: Dash callbacks that execute CRUD reads and update the UI

### File Structure

```
original/
├── notebooks/
│   └── ProjectTwoDashboard.ipynb    # Main Dash dashboard application
├── animal_shelter/
│   ├── __init__.py                  # Package initialization
│   ├── animal_shelter.py            # CRUD operations module (428 lines)
│   └── data_importer.py             # Data import functionality
├── assets/
│   ├── aac_shelter_outcomes.csv     # Austin Animal Center dataset
│   └── styles.css                   # Custom styles
├── scripts/
│   ├── get_csv_data.sh              # CSV data retrieval
│   └── startup.sh                   # Container startup script
├── docker-compose.yml                # Docker services configuration
├── Dockerfile.importer               # Data importer container
├── import_aac_data.py                # Python data import script
├── test_animal_shelter.py            # Unit tests
├── requirements.txt                  # Python dependencies
└── README.md                         # Project documentation
```

## Core Components

### 1. AnimalShelter Class (`animal_shelter/animal_shelter.py`)

**Purpose**: Provides CRUD operations for MongoDB animals collection

**Key Methods**:
- `create(data: Dict) -> bool`: Insert new animal document
- `read(criteria: Dict = None) -> List[Dict]`: Query animals with optional filters
- `update(criteria: Dict, update_spec: Dict) -> int`: Update matching documents
- `delete(criteria: Dict) -> int`: Delete matching documents
- `ensure_indexes() -> None`: Create performance indexes

**Connection Management**:
- Uses PyMongo MongoClient
- Environment-based configuration (user, password, host, port)
- Connection string format: `mongodb://user:pass@host:port`
- Default database: `aac`, collection: `animals`

### 2. Dashboard Application (`notebooks/ProjectTwoDashboard.ipynb`)

**Components**:

#### Filter Controls
- **Reset**: Shows all animals
- **Water Rescue**: Filters for Labrador, Chesapeake Bay Retriever, Newfoundland breeds
- **Mountain or Wilderness Rescue**: Filters for German Shepherd, Alaskan Malamute, Old English Sheepdog, Rottweiler, Saint Bernard breeds
- **Disaster or Individual Tracking**: Filters for German Shepherd, Bloodhound, Belgian Malinois breeds

**Data Table**:
- Sortable columns
- Pagination support
- Single-row selection
- Visible columns: `animal_id`, `name`, `animal_type`, `breed`, `age_upon_outcome`, `outcome_type`, `sex_upon_outcome`, `datetime`
- Hidden coordinate columns for map integration

**Map Visualization**:
- Uses `dash-leaflet` for geospatial display
- Centers on selected animal
- Marker clustering for multiple locations
- Base layer switching (OSM/Toner/Terrain)
- Auto-fit bounds and scale control

**Chart Visualization**:
- Uses ECharts (`dash-echarts`) for breed statistics
- User-selectable chart types: Bar, Pie, Treemap
- Displays top breeds based on filtered data

**Branding**:
- Grazioso Salvare logo (clickable, links to SNHU)
- Unique identifier (name)

### 3. Data Import (`import_aac_data.py`)

**Functionality**:
- Imports CSV data into MongoDB
- Data validation and cleaning
- Batch processing for large datasets
- Duplicate detection and prevention
- Import statistics and reporting

## MongoDB Data Patterns

### Query Patterns

1. **Rescue Category Filtering**:
   ```python
   {
     "$and": [
       {"animal_type": "Dog"},
       {"breed": {"$regex": "Labrador|Chesapeake Bay Retriever|Newfoundland", "$options": "i"}},
       {"sex_upon_outcome": {"$regex": "Intact", "$options": "i"}}
     ]
   }
   ```

2. **Performance Optimizations**:
   - Projection fields to limit data transfer
   - Row limiting (`MAX_ROWS` default: 2000)
   - Index creation on common query fields
   - Server-side filtering (no client-side DataFrame building)

### Indexes

The `ensure_indexes()` method creates indexes on:
- `animal_type`
- `breed`
- `age_upon_outcome`
- Common query field combinations

### Data Model

**Collection**: `animals`  
**Database**: `aac`

**Key Fields**:
- `animal_id`: Unique identifier
- `name`: Animal name
- `animal_type`: Type (Dog, Cat, etc.)
- `breed`: Breed name
- `age_upon_outcome`: Age at outcome
- `outcome_type`: Outcome (Adoption, Transfer, etc.)
- `sex_upon_outcome`: Sex and spay/neuter status
- `datetime`: Date/time of outcome
- `location_lat` / `location_long`: Geographic coordinates (variations: `lat`, `lon`, `latitude`, `longitude`, `x`, `y`)

## UI Components and Interactions

### User Interactions

1. **Filter Selection**: User clicks filter button → Callback updates filtered data → All widgets refresh
2. **Table Row Selection**: User selects row → Map centers on animal → Chart updates with breed data
3. **Chart Type Selection**: User changes chart type → Chart re-renders with same data, different visualization

### Callback Flow

```
Filter Button Click
  ↓
Update filtered data store
  ↓
Update table data
  ↓
Update map center/marker
  ↓
Update chart data
```

## Current Limitations

1. **Architecture**: Monolithic Jupyter notebook, not production-ready
2. **Security**: No authentication or authorization
3. **Scalability**: Client-side data loading, limited to 2000 rows
4. **Deployment**: Requires Jupyter environment, not containerized
5. **Testing**: Limited test coverage, notebook-based testing
6. **API**: No RESTful API, direct database access from UI
7. **Error Handling**: Basic error handling, no comprehensive logging
8. **Audit Trail**: No audit logging for data operations

## Enhancement Opportunities

### Software Design/Engineering
- Transform to three-tier architecture (presentation, business logic, data access)
- Implement RESTful API layer
- Add authentication and authorization
- Containerize application
- Implement comprehensive error handling and logging

### Algorithms and Data Structures
- Implement server-side pagination
- Add caching layer (Redis)
- Optimize search with advanced data structures (Trie, inverted index)
- Implement fuzzy search capabilities

### Databases
- Add audit logging collection
- Implement advanced aggregation pipelines
- Create materialized views for analytics
- Optimize indexes for query patterns

## Dependencies

**Python Packages**:
- `dash`: Web framework
- `dash-table`: Data table component
- `dash-leaflet`: Map visualization
- `dash-echarts`: Chart visualization
- `pymongo`: MongoDB driver
- `pandas`: Data manipulation
- `python-dotenv`: Environment variable management

**External Services**:
- MongoDB database (local or remote)
- Map tile services (OpenStreetMap, Stamen)

## Data Flow

```
CSV File (aac_shelter_outcomes.csv)
  ↓
import_aac_data.py
  ↓
MongoDB (aac.animals collection)
  ↓
AnimalShelter.read()
  ↓
Dash Callbacks
  ↓
UI Components (Table, Map, Chart)
```

## Next Steps for Enhancement

1. Extract business logic from notebook into separate modules
2. Create RESTful API endpoints
3. Build React frontend to replace Dash components
4. Implement authentication/authorization
5. Add audit logging
6. Containerize application
7. Set up CI/CD pipeline
8. Write comprehensive tests

