"""
Animal data models.
"""
from pydantic import BaseModel, Field
from typing import Optional, Dict, Any
from datetime import datetime


class AnimalBase(BaseModel):
    """Base animal model."""
    animal_id: Optional[str] = None
    name: Optional[str] = None
    animal_type: Optional[str] = None
    breed: Optional[str] = None
    age_upon_outcome: Optional[str] = None
    outcome_type: Optional[str] = None
    sex_upon_outcome: Optional[str] = None
    datetime: Optional[str] = None


class AnimalCreate(AnimalBase):
    """Model for creating an animal."""
    animal_id: str = Field(..., description="Unique animal identifier")


class AnimalUpdate(BaseModel):
    """Model for updating an animal."""
    name: Optional[str] = None
    animal_type: Optional[str] = None
    breed: Optional[str] = None
    age_upon_outcome: Optional[str] = None
    outcome_type: Optional[str] = None
    sex_upon_outcome: Optional[str] = None
    datetime: Optional[str] = None


class AnimalResponse(AnimalBase):
    """Model for animal response."""
    id: str = Field(..., alias="_id", description="MongoDB document ID")
    
    class Config:
        populate_by_name = True
        json_schema_extra = {
            "example": {
                "_id": "507f1f77bcf86cd799439011",
                "animal_id": "A123456",
                "name": "Buddy",
                "animal_type": "Dog",
                "breed": "Golden Retriever",
                "age_upon_outcome": "2 years",
                "outcome_type": "Adoption",
                "sex_upon_outcome": "Neutered Male",
                "datetime": "2024-01-15 10:30:00"
            }
        }


class AnimalListResponse(BaseModel):
    """Model for paginated animal list response."""
    items: list[AnimalResponse]
    total: int
    skip: int
    limit: int


class RescueCategoryFilter(BaseModel):
    """Model for rescue category filter."""
    category: str = Field(..., description="Rescue category: Reset, Water Rescue, Mountain or Wilderness Rescue, Disaster or Individual Tracking")

