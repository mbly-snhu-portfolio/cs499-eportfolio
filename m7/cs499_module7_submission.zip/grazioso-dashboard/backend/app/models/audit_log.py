from datetime import datetime
from typing import Dict, Any, Optional
from pydantic import BaseModel, Field

class AuditLog(BaseModel):
    """
    Pydantic model for Audit Log entries.
    Ensures strict typing and validation for audit records.
    """
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    user_id: str
    username: str
    action: str
    collection: str
    document_id: Optional[str] = None
    changes: Dict[str, Any] = Field(default_factory=dict)
    ip_address: Optional[str] = None
    user_agent: Optional[str] = None
    success: bool = True
    error_message: Optional[str] = None

    class Config:
        arbitrary_types_allowed = True
